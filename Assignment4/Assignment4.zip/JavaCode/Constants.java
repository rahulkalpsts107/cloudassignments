package com.aws.assignment3.util;

public final class Constants {
	public static final String INSTANCE1 = "i-f6fd3d2e";
	public static final String INSTANCE2 = "i-fdcf673a";
	public static final String INSTANCE3 = "i-7b69c4a3";
	public static final String LOAD_BALANCER = "MyProgramElasticLoadBalancer";
	public static final String IMAGE_ID = "ami-f0091d91";
	public static final String AUTOSCALE_GROUP = "MyAutoScaleGroup";
	public static final String INSTANCE_TYPE = "t2.micro";
}
