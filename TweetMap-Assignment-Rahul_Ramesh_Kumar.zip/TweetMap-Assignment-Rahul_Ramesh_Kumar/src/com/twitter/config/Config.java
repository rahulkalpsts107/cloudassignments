package com.twitter.config;

public final class Config {
	public static final String STREAM_URI = "https://stream.twitter.com/1.1/statuses/filter.json";
	public static final String CONSUMER_KEY="VukXT0veRUnXmUsFfM9Dc9bIm";
	public static final String CONSUMER_SECRET="OsnSHK6dpBY5c1FPsq5Do9oQFasU5pOm2m62ONiRzFh2kquXDy";
	public static final String ACCESS_TOKEN="82085950-k1K9nQcBgzBAC0gNdhoQh7FwGChvLEdyI9YitzFh4";
	public static final String ACCESS_TOKEN_SECRET="1ODFNvbYqhhu6lqevNuNXwnVSojUElVZHyTyeGB9Ni5Tm";
	public static final String HASHTAGS_RACING_SPORT = "f1,Formula1,F12016,f12016,motorsport,superbike,sbk,nascar,lemans/"
			+ "f1jp,honda,mclarenhonda,ferrari,indy,motogp,bmw,MotorSport,NASCAR,Racing,daytona,fia,FIA,Indy,wrc,sbk,Superbike,SuperBike";
	public static final String DOMAIN ="twittermap";
	public static final String ENDPOINT="https://search-twittermap-jjkboykwtol6fh52oibv7w4nbq.us-west-2.es.amazonaws.com";
}
